﻿using Newtonsoft.Json;

namespace $safeprojectname$.models
{
    public class TypeElement
    {
        [JsonProperty("type")]
        public TypeClass Type { get; set; }
    }
}
