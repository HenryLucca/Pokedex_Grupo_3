﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace $safeprojectname$.models
{
    public class Types
    {
        [JsonProperty("pokemon")]
        public List<PokemonElement> Pokemon { get; set; }
    }
}
