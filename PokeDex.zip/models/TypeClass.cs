﻿using Newtonsoft.Json;

namespace $safeprojectname$.models
{
    public class TypeClass
    {
        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
