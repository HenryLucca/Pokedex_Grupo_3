﻿using Newtonsoft.Json;

namespace $safeprojectname$.models
{
    public class AbilityElement
    {
        [JsonProperty("ability")]
        public TypeClass Ability { get; set; }
    }
}
