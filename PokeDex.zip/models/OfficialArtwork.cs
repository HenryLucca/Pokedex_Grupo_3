﻿using Newtonsoft.Json;

namespace $safeprojectname$.models
{
    public class OfficialArtwork
    {
        [JsonProperty("front_default")]
        public string Front_Default { get; set; }
    }
}
