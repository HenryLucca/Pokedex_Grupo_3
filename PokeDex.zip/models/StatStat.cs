﻿using Newtonsoft.Json;

namespace $safeprojectname$.models
{
    public class StatStat
    {
        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
