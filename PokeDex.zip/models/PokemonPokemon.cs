﻿using Newtonsoft.Json;

namespace $safeprojectname$.models
{
    public class PokemonPokemon
    {
        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
