﻿using Newtonsoft.Json;

namespace $safeprojectname$.models
{
    public class PokemonElement
    {
        [JsonProperty("pokemon")]
        public PokemonPokemon Pokemon { get; set; }
    }
}
